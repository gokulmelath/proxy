package com.proxyserver.controller;

import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.net.URI;

@RestController
public class ForwardController {
    private final RestTemplate restTemplate = new RestTemplate();

    @RequestMapping("/**")
    public ResponseEntity<String> forward(@RequestBody(required = false) String body,
                                          @RequestHeader HttpHeaders headers,
                                          HttpMethod method,
                                          @RequestHeader("X-Forwarded-Host") String originalHost,
                                          @RequestHeader("X-Original-URL") String originalUrl) throws Exception {
        URI uri = new URI("http://" + originalHost + originalUrl);
        HttpEntity<String> entity = new HttpEntity<>(body, headers);
        return restTemplate.exchange(uri, method, entity, String.class);
    }
}
