package com.proxyserver.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

@RestController
public class ProxyServerTestController {

    private final RestTemplate restTemplate = new RestTemplate();

    @GetMapping("/proxy")
    public ResponseEntity<String> proxy(@RequestParam String url) {
        return ResponseEntity.ok(restTemplate.getForObject(url, String.class));
    }
}
