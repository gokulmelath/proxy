package com.shipproxy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProxyClientApplicationTests {

    @Test
    void contextLoads() {
    }
}
