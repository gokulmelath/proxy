package com.shipproxy.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

@RestController
public class ProxyTestController {

    @Value("${proxy.server.url}")
    private String proxyServerUrl;

    private final RestTemplate restTemplate = new RestTemplate();

    @GetMapping("/proxy")
    public ResponseEntity<String> proxy(@RequestParam String url) {
        return ResponseEntity.ok(restTemplate.getForObject(proxyServerUrl + "/proxy?url=" + url, String.class));
    }
}
