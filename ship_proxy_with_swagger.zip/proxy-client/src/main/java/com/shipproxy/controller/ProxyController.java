package com.shipproxy.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.util.concurrent.*;

@RestController
public class ProxyController {

    private final RestTemplate restTemplate = new RestTemplate();
    private final BlockingQueue<Callable<ResponseEntity<String>>> queue = new LinkedBlockingQueue<>();

    public ProxyController() {
        Executors.newSingleThreadExecutor().submit(() -> {
            while (true) {
                try {
                    Callable<ResponseEntity<String>> task = queue.take();
                    task.call();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    @Value("${proxy.server.url}")
    private String proxyServerUrl;

    @RequestMapping("/**")
    public ResponseEntity<String> proxy(@RequestBody(required = false) String body,
                                        @RequestHeader HttpHeaders headers,
                                        HttpMethod method,
                                        @RequestParam(required = false) MultiValueMap<String, String> params,
                                        @RequestHeader("Host") String host,
                                        @RequestHeader("X-Original-URL") String originalUrl) throws Exception {

        URI uri = new URI(proxyServerUrl + originalUrl);
        HttpEntity<String> entity = new HttpEntity<>(body, headers);

        CompletableFuture<ResponseEntity<String>> future = new CompletableFuture<>();
        queue.offer(() -> {
            try {
                ResponseEntity<String> response = restTemplate.exchange(uri, method, entity, String.class);
                future.complete(response);
                return response;
            } catch (Exception e) {
                future.completeExceptionally(e);
                return null;
            }
        });
        return future.get();
    }
}
